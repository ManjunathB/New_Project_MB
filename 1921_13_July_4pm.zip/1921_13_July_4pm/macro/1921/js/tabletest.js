$(document).ready(function(){
var table= $('#example1').DataTable(
 {
	iDisplayLength:-1 ,
	"scrollY": "50%",
	"scrollX": true,
	"scrollCollapse": true,
	"bDestroy":true,	
	"filter":true,
	"paging":true,
	"autoWidth": true,

 });
 
$('#example1').parents('div.dataTables_wrapper').first().hide();	
 
$("#selectecu, #viewsignal, #signalstate").change(function(){
	$(".action").val("applicable");							// by default "applicable"
	setAction();  											//function call	
	
	if($("#selectecu").val() && $("#viewsignal").val() && $("#signalstate").val() ){
		$('#example1').parents('div.dataTables_wrapper').first().show();	
	}else{
		$('#example1').parents('div.dataTables_wrapper').first().hide();
	}
}); 
 
 
});

function setAction(){

var selectecu = $("#selectecu").val();
var viewsignal = $("#viewsignal").val();
var signalstate = $("#signalstate").val();
if(selectecu && viewsignal && signalstate){
	var datatosend = {
	    CGISESSID:$("#CGISESSID").val(),
		macro:'ecuwisetest',
		secu:selectecu,
		vsignal:viewsignal,
		sstate:signalstate,
		on_change:'on_change'
		};
	$.ajax({
			url: $("#SCRIPTPATH").val()+'/cgi/macrocall.cgi',
			method: 'POST',
			data: datatosend,
			success: function(response) {
				    $(".example1").show();
					var mainresponce = [];
					mainresponce =response.split("!@!"); 
					$.each(mainresponce, function( index, value ) {
					   var field = value.split("!!");
					   $("#"+field[0]).val(field[1]);
						});
				}
			}
		});
 }

}

 
 
//set auto height -calculation
jQuery.event.add(window, "load", resizeTable);              
jQuery.event.add(window, "resize", resizeTable);           
function resizeTable()    
{ 			
	SetHeight();                       
}
function SetHeight(){
					var h = $(window).height();
					// alert(h);
					 // $(".panel").height(h-100);  
					
			}