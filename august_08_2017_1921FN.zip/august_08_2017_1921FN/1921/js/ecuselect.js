$(document).ready(function(){
    $(".table").hide();
	$("#selectecu").change(function(){
		var sel_ecu= this.value;
		if(sel_ecu){
			var datatosend = {
			CGISESSID: $('#CGISESSID').val(),
			macro: 'ecuselect',       
			sel_ecu: sel_ecu
		   };
		   //alert(datatosend);
			$.ajax({ 
				url: $('#SCRIPTPATH').val() + '/cgi/macrocall.cgi',
				method: 'POST',
				data: datatosend,
				success: function(response) {
                window.location.reload(true);
					}
			});
		}
	});
	
	
	$("#viewsignal").change(function(){
		var sel_type= this.value;
		if(sel_type){
			var datatosend = {
			CGISESSID: $('#CGISESSID').val(),
			macro: 'ecuselect',       
			sel_type: sel_type
		   };
		   //alert(datatosend);
			$.ajax({
				url: $('#SCRIPTPATH').val() + '/cgi/macrocall.cgi',
				method: 'POST',
				data: datatosend,
				success: function(response) {
			}
			});
		}
	});
	
	
	$("#signalstate").change(function(){
		var sel_state= this.value;
		if(sel_state){
			var datatosend = {
			CGISESSID: $('#CGISESSID').val(),
			macro: 'ecuselect',       
			sel_state: sel_state
		   };
		   //alert(datatosend);
			$.ajax({
				url: $('#SCRIPTPATH').val() + '/cgi/macrocall.cgi',
				method: 'POST',
				data: datatosend,
				success: function(response) {
				$(".table").show();
             
			}
			});
	}
	
 });
 
 });
 