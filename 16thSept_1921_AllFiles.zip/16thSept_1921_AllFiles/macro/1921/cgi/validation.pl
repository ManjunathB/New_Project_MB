#!/usr/sbin/perl
use Data::Dumper;
use PSESSION;
use CGI;

sub preMacroCheck
{

my $q = CGI->new();
my $CGISESSID = $q->param('CGISESSID');
print my $signalname = $q->param('selectecu');
my $u = User->new();
my $SCRIPTPATH = $u->getAppBaseUrl();
my $ps = PSESSION->new();
my $ps_outref = $ps->getSessionData($CGISESSID);
my $admin_obj = ADMINNEW->new($proj, $username);
my $ecutable	 = "P".$proj."_ecutable";
my $SIGNAL_TYPE = "P".$proj."_SIGNAL_TYPE";
my $SIGNAL_DETAILS = "P".$proj."_SIGNAL_DETAILS";
my $assumption_details   =  $admin_obj->fetchTableData('tablename'=>$ecutable, 'fields'=> "ecuname");
my $assumption_details1  = $admin_obj->fetchTableData('tablename'=>$SIGNAL_TYPE, 'fields'=>"STNAME");
my $ecu_details	= $admin_obj->getQueryData("query"=>"SELECT * FROM $SIGNAL_DETAILS");
$datahash{error_message}="$error_message_show";
return %datahash;
    
}
   

