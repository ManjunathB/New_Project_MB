$(document).ready(function(){

 $(".editsignal").hide();
	$("#purpose").change(function(){
		var sel_signal= this.value;
		if(sel_signal){
			var datatosend = {
			CGISESSID: $('#CGISESSID').val(),
			macro: 'dbupdate',       
			signal: sel_signal
		   };
		   //alert(datatosend);
			$.ajax({
				url: $('#SCRIPTPATH').val() + '/cgi/macrocall.cgi',
				method: 'POST',
				data: datatosend,
				success: function(response) {
					}
			});
		}
	});

 });
 