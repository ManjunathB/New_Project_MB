$(document).ready(function(){
var table= $('#example1').DataTable(
 {
	iDisplayLength:-1 ,
	"scrollY": "50%",
	"scrollX": true,
	"scrollCollapse": true,
	"bDestroy":true,	
	"filter":true,
	"paging":true,
	"autoWidth": true,

 });
 
 });
 
//set auto height -calculation
jQuery.event.add(window, "load", resizeTable);              
jQuery.event.add(window, "resize", resizeTable);           
function resizeTable()    
{ 			
	SetHeight();                       
}
function SetHeight(){
					var h = $(window).height();
					// alert(h);
					 // $(".panel").height(h-100);  
					
			}