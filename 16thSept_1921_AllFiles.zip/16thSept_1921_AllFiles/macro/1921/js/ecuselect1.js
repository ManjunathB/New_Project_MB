$(document).ready(function(){
	$("#selectecu").change(function(){
		var sel_ecu= this.value;
		alert(sel_ecu);
		var sel_type = this.value;
		var sel_state = this.value;
		if(sel_ecu){
			var datatosend = {
			CGISESSID: $('#CGISESSID').val(),
			macro: 'ecuselect',       
			sel_ecu: sel_ecu,
			sel_type: sel_type,
			sel_state: sel_state
		   };
		   //alert(datatosend);
			$.ajax({ 
				url: $('#SCRIPTPATH').val() + '/cgi/macrocall.cgi',
				method: 'POST',
				data: datatosend,
				success: function(response) {
                $("#test").html(response);
				}
			});
		}
 });
 });