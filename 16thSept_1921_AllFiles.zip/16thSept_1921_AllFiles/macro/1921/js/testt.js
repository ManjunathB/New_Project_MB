$(document).ready(function() {

    function addRemoveClass(theRows) {

        theRows.removeClass("odd even");
        theRows.filter(":odd").addClass("odd");
        theRows.filter(":even").addClass("even");
    }
    
     $(document).on('keyup','#myInput',function(){
     				var selected = $("#selectecu").val();
            var search=$("#myInput").val();            
            search=search.toLowerCase();            
            $('tr[id!="HeadRow"]').hide();
            $('tr[id!="HeadRow"]').each(function(){            
                var obj=$(this);
                var productName=obj.first('td').html();
                productName=productName.toLowerCase();
                if(productName.search(search)>=0)
                {
                    if(selected!= "All")
                    {
                      if(obj.attr('position')==selected)
                      {
                      obj.show();
                      }
                    }else{
                      obj.show();
                    }
                }               
            });
        });

    var rows = $("table#example1 tr:not(:first-child)");

    addRemoveClass(rows);


    $("#selectecu").on("change", function() {

        var selected = this.value;

        if (selected != "All") {

            rows.filter("[position=" + selected + "]").show();
            rows.not("[position=" + selected + "]").hide();
            var visibleRows = rows.filter("[position=" + selected + "]");
            addRemoveClass(visibleRows);
        } else {

            rows.show();
            addRemoveClass(rows);

        }

    });
});