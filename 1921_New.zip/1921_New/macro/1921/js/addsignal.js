function on_sbmt(){
var errMsg ='Please select the following:\n \n';
	var isError = false;
	if(($("#platforme").val()) == ''){
		errMsg += "Platform Name \n";
		isError = true;
	}
	if(($("#proj_name").val()) == ''){
		errMsg += "Project Name \n";
		isError = true;
	}
	if(($("#func_name").val()) == ''){
		errMsg += "Function Name \n";
		isError = true;
	}
	if(isError){
		alert(errMsg);
	}
	else{
		var proj_name = $("#proj_name").val();
		var func_name = $("#func_name").val();
		var applicable_arr	 = [];
		var NA_action_arr	 = [];
		var NA_action_id_arr = [];
		var applicable_id_arr= [];
		
		$('.action').each(function(){
			if((this.value)== "NA"){
				NA_action_arr.push(this.id);
			}else{
				applicable_arr.push(this.id);
			}
		});
		
		$.each(NA_action_arr,function(index, value){
				var id= value.split("_");
				NA_action_id_arr.push(id[1]);
		});
		$.each(applicable_arr,function(index, value){
				var id= value.split("_");
				applicable_id_arr.push(id[1]);
		});
		
		var applicable_deliverable = applicable_id_arr.join("!!");   
		var NA_deliverable = NA_action_id_arr.join("!!");                                       // creating a string of NA action 
		var datatosend = { 
			macro:'setDeliverable_Action',
			proj_name:proj_name,
			CGISESSID:$("#CGISESSID").val(),
			func_name:func_name,		
			update_iss:'update_iss',		
			NA_deliverable:NA_deliverable,
			applicable_deliverable:applicable_deliverable
		};
	$.ajax({
			url: $("#SCRIPTPATH").val() + '/cgi/macrocall.cgi',
			method: 'POST',
			data: datatosend,
			success: function(data) {				
				if (data == ''){
					alert ("Nothing updated..!!");
					}
				else{
					alert(data);
				}
			}
		});
	}
}